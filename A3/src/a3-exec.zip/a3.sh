#!/bin/bash

# Assignment 3 run script

export PYTHONPATH=$PYTHONPATH:.
python3 a3.py
