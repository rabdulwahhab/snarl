#!/bin/bash

# a4 run script

export PYTHONPATH=$PYTHONPATH:.
python3 a4.py "$@"
