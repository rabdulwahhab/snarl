# Defined Colors

GROUND = (230, 255, 238)
WALL = (128, 42, 0)
GRASS = (0, 153, 0)
DOOR = (153, 0, 51)
STAIR = (0, 119, 179)

PLAYER = (230, 251, 255)
ENEMY = (230, 0, 0)

ITEM = (128, 149, 255)
KEY = (153, 128, 0)

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
