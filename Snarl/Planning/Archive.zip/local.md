![snarl diagram of data](./snarlDiagram.jpg)
